﻿using System.Windows;
using System.Windows.Controls;

namespace Workshop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public decimal fee = 0;
        public decimal charge = 0;
        public decimal total = 0;
        public decimal UserDay = 0;
        public decimal totalDayCharge = 0;
        private int PhoneNumberNum = 0;

        enum Choices
        {
            HandlingStress,
            TimeManagement,
            supervisionSkills,
            Negogiation,
            HowToInterview
        }

        public MainWindow()
        {
            InitializeComponent();
      
        }
        private void PhoneNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            string PhoneNumberTxt = PhoneNumber.Text;
            try
            {
                PhoneNumberNum = int.Parse(PhoneNumberTxt);
            }
            catch
            {
                if (PhoneNumberTxt == "")
                {
                    PhoneNumberNum = 0;
                }
            }

            // filter invalid input
            PhoneNumberTxt = PhoneNumberNum == 0 ? "" : $"{PhoneNumberNum}";

            PhoneNumber.Text = PhoneNumberTxt;

            // move the cursor to the end
            PhoneNumber.Select(PhoneNumberTxt.Length, 0);
        }

        private void ListBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            ListBox listBox = sender as ListBox;
            try
            {
                if (listBox != null)
                {
                    ListBoxItem lbi = listBox.SelectedItem as ListBoxItem;
                    Choices index = (Choices)listBox.SelectedIndex;
                    string message = "";
                    switch (index)
                    {
                        case Choices.HandlingStress:
                            {
                                message = $"{lbi.Content as string} is selected";
                                UserDay = 3;
                                UserDays.Content = 3;
                                fee = 1000;
                                UserFee.Content = fee.ToString("C");
                                break;
                            }
                        case Choices.TimeManagement:
                            {
                                message = $"{lbi.Content as string} is selected";
                                UserDays.Content = 3;
                                UserDay = 3;
                                fee = 800;
                                UserFee.Content = fee.ToString("C");
                                break;
                            }
                        case Choices.supervisionSkills:
                            {
                                message = $"{lbi.Content as string} is selected";
                                UserDays.Content = 3;
                                UserDay = 3;
                                fee = 1500;
                                UserFee.Content = fee.ToString("C");
                                break;
                            }
                        case Choices.Negogiation:
                            {
                                message = $"{lbi.Content as string} is selected";
                                UserDays.Content = 5;
                                UserDay = 5;
                                fee = 1300;
                                UserFee.Content = fee.ToString("C");
                                break;
                            }
                        case Choices.HowToInterview:
                            {
                                message = $"{lbi.Content as string} is selected";
                                UserDays.Content = 1;
                                UserDay = 1;
                                fee = 500;
                                UserFee.Content = fee.ToString("C");
                                break;
                            }
                        default:
                            {
                                message = "Make an actual choice";
                                charge = 0;
                                fee = 0;
                                UserDay = 0;
                                ChargePerDay.Content = null;
                                UserDays.Content = null;
                                UserFee.Content = null;
                                break;
                            }
                    }
                }
            }
            catch
            {
                charge = 0;
                fee = 0;
                UserDay = 0;
                ChargePerDay.Content = null;
                UserDays.Content = null;
                UserFee.Content = null;
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Austin.IsChecked == true)
                {
                    charge = 150;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else if (Chicaco.IsChecked == true)
                {
                    charge = 225;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else if (Dallas.IsChecked == true)
                {
                    charge = 175;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else if (Orlando.IsChecked == true)
                {
                    charge = 300;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else if (Phoenix.IsChecked == true)
                {
                    charge = 175;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else if (Raleigh.IsChecked == true)
                {
                    charge = 150;
                    ChargePerDay.Content = charge.ToString("C");
                }
                else
                {
                    MessageBox.Show("Please select a location");
                    charge = 0;
                    fee = 0;
                    UserDay = 0;
                    ChargePerDay.Content = null;
                    UserDays.Content = null;
                    UserFee.Content = null;
                }
            }

            catch
            {
                _ = MessageBox.Show("Please fill all field");
                charge = 0;
                fee = 0;
                UserDay = 0;
                ChargePerDay.Content = null;
                UserDays.Content = null;
                UserFee.Content = null;




            }
            Calculation();
        }

        private void Calculation()
        {
            if (ChargePerDay.Content != null || UserDays.Content != null || UserFee.Content!=null)
            {
                totalDayCharge = UserDay * charge;
                total = fee + totalDayCharge;
                TotalPrice.Content = total.ToString("C");
            }
            else
            {
                charge = 0;
                fee = 0;
                UserDay = 0;
                ChargePerDay.Content = null;
                UserFee.Content = null;
                UserFee.Content = null;
            }
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            TotalPrice.Content = null;
            UserName.Text = null;
            PhoneNumber.Text = null;
            ChargePerDay.Content = null;
            UserDays.Content = null;
            UserFee.Content = null;
            Austin.IsChecked = false;
            Chicaco.IsChecked = false;
            Dallas.IsChecked = false;
            Orlando.IsChecked = false;
            Phoenix.IsChecked = false;
            Raleigh.IsChecked = false;

        }
    }
}